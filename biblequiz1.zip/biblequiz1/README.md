# biblequiz1

A Pen created on CodePen.io. Original URL: [https://codepen.io/Jerry-Castro/pen/BaXXVoK](https://codepen.io/Jerry-Castro/pen/BaXXVoK).

